S3 Table. Monthly and snapshot indicator tables.
All monthly series and quarterly-snapshot statistics underlying Figs 1-9 and Tables 2-5 of
"Mapping the stablecoin transfer network on Ethereum after netting out flash loans, 2020-2026".

flow_composition_month.csv        Fig 1A-B, S1 Table: gross/net value, flash-loan-like share, netting reduction, G_simple value (simple_usd; divide by net_usd for the
                                  net-value share of Fig 1B) and G_simple event counts (simple_n / all_n count ALL non-mint events, dust included)
dyad_month.csv                    Fig 1C: EOA/SC dyad shares under G_all and G_net
concentration_all_schemes.csv     Fig 3, Table 2 (also n_transfers, volume_usd, n_receivers, n_senders by definition): Gini, top-0.1%/1% shares, Nakamoto N50 under G_all, G_net, G_simple (G_net_xf for DAI);
                                  also Fig 1B and S1 Table: the filtered count share of payment-like transfers = n_transfers(G_simple) / n_transfers(G_all)
concentration_entity_level.csv    Fig 4, Table 2: same statistics under G_net_entity and G_net_entity_xissuer
concentration_dai_net_xf.csv      Fig 2B: DAI under G_net_xf
dai_flashmint_share.csv           Fig 2A: share of DAI net inflow absorbed by the flash-mint module
dai_inflow_destination_month.csv  Fig 2C: destination of DAI net inflow by category
inflow_by_category_month.csv      Fig 5, S2 Table: net inflow by labelled category (USD)
inflow_category_share_month.csv   Fig 5, S2 Table: the same as shares
top_receivers_net.csv             Table 3: 20 largest recipients per token-month (address level, G_net)
top_receivers_entity.csv          Table 3: 20 largest recipients per token-month (entity level)
table2_concentration_summary.csv  Table 2: annual means, Kendall tau and p-values
kendall_tau_by_scheme.csv         Table 2: trend tests by network definition
event_effects_placebo.csv         S6 Table, Results (Stress episodes): event-month changes and placebo percentiles under G_net, G_net_xf and G_simple
                                  (the G_all event-month levels quoted in Results come from concentration_all_schemes.csv)
topology_metrics.csv              Fig 6, Table 4: 27 quarterly snapshots per token
alpha_fixed_xmin.csv              Fig 6F, Table 4: degree tail exponents with x_min fixed at 10
degree_fits_k10.csv               Table 4, S2 Text: discrete power-law fits on the k >= 10 tail with no bound on alpha (powerlaw's default alpha <= 3 lifted), likelihood-ratio
                                  comparisons vs log-normal, exponential and truncated power law; plus the continuous fit at the KS-selected x_min for reference
tail_fits_strength.csv            Fig 8: continuous power-law fits of in-/out-strength for 40 months (the 27 quarterly snapshots plus the 13 preferential-attachment
                                  months); the statistics reported in the paper use the 27 quarterly snapshots (January, April, July, October)
pa_results.csv                    Fig 9, Table 5: preferential-attachment exponents by month pair
pa_results_survival.csv           Table 5 (beta_surv, beta_cum): survival-conditioned binned estimates and the cumulative-function estimates by month pair
alpha_cutoff_sensitivity.csv      Results (degree distributions), S2 Text: discrete tail exponents with the cut-off at k >= 5, 10 and 20 for every snapshot and direction
pa_synthetic_check.csv            Methods (Preferential attachment): synthetic validation of the binned and cumulative estimators (5 seeds x beta = 0.5, 1.0, 1.5)
