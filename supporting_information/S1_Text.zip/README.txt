S1 Text / Zenodo deposit: code and label table for
"Mapping the stablecoin transfer network on Ethereum after netting out flash loans, 2020-2026: rising concentration in USDT,
super-linear preferential attachment and the retreat of payment-like transfers".

Data source: Google BigQuery public dataset bigquery-public-data.crypto_ethereum (tables token_transfers, contracts,
transactions), queried on 6 October 2026, blocks to 30 September 2026. Replace YOUR_PROJECT in every file with your
own Google Cloud project ID and create a US-multi-region dataset named `stable` before running the SQL.

SQL (GoogleSQL):
  pipeline_run_order.sql         blocks 1-8: materialise transfers, contracts, tx_meta, transfers_netted; monthly concentration under
                                 G_all / G_net / G_simple; flow composition; dyad shares; top-20 recipients under G_net
  dai_exclude_flashmint.sql      G_net_xf for DAI (flash-mint module excluded) and the flash-mint share series
  entity_level_queries.sql       Q11-Q13: entity-level concentration, inflow by labelled category, entity-level top-20 (requires the labels table)
  top_receivers.sql              gross-definition top recipients used for the hub analysis
  first_look_concentration.sql   the initial single-definition concentration query (kept for provenance)
  followup_queries_Q14_Q16.sql   decomposition of flash-loan-like round trips (2022 USDC; 2025-2026 USDC/USDT) and gas of direct calls (S4 Table)
  followup_queries_Q17_Q18.sql   DAI round trips by address and year (S4 Table) and the shares of the 10/100/1,000 largest recipients by month (S5 Table)
  followup_queries_Q19.sql       shares of the 250 to 25,000 largest recipients by month, the fixed counts that bracket the size of the top 1% in 2020 and 2026 (S5 Table)
Python 3.12 (pandas, numpy, scipy, python-igraph, powerlaw, matplotlib; google-cloud-bigquery for streaming edge lists):
  topology_snapshots.py          27 quarterly G_net snapshots per token: bow-tie, reciprocity, assortativity, k-core, degree histograms,
                                 KS-selected and fixed-x_min degree fits
  pa_fix.py                      preferential attachment on 13 month pairs per token (binned and cumulative estimators)
  pa_survival.py                 the same test conditioned on old nodes still active in month t+1 (robustness check; needs the cached edge lists)
  pa_synthetic_check.py          synthetic validation of the two estimators on an empirical degree distribution (Methods)
  strength_fits.py               continuous power-law fits of in-/out-strength with x_min search (3-significant-figure rounding)
  refit_tail_k10.py              model comparisons on the k >= 10 degree tails with powerlaw's default alpha bound ([0, 3]) lifted (Table 4);
                                 offline_fits.py (superseded: its log-normal comparisons at the KS cut-off were affected by that bound) and degree_analysis.py are kept for provenance
  make_figures_en.py             Figs 1-9 (300 dpi RGB TIFF)
  verify_numbers.py              recomputes every statistic quoted in the manuscript from the exported CSVs
  q19_summary.py                 annual means, Kendall's tau and the like-for-like comparison at the size of the 2026 top 1% from the Q19 export
Environment:
  requirements.txt               package versions used (Python 3.12; pandas 3.0.6, numpy 2.5.3, scipy 1.18.1, python-igraph 1.0.0, powerlaw 2.0.0, matplotlib 3.11.2, google-cloud-bigquery 3.46.1)
Label table:
  labels_final.csv               96 addresses: entity, entity_group, category, confidence, source note (English)
Licence:
  LICENSE.txt                    MIT for the code; the label table and the indicator tables are CC BY 4.0
