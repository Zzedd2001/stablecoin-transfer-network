S4 Table. Decomposition of flash-loan-like round-trip value and gas of direct calls.

q14a_usdc2022_roundtrip_by_address.csv  USDC 2022: 40 most active participating addresses in flash-loan-like round trips (share = share of round-trip gross value in which the address is one endpoint)
q14b_usdc2022_roundtrip_by_entry.csv    USDC 2022: the same value by entry contract (the contract called by the signing account) with number of distinct signers
q14c_usdc_roundtrip_month_top5.csv      USDC 2021-2023 by month: round-trip value and the share involving the five most active addresses of 2022
q15a_roundtrip_2025_2026_by_address.csv USDC and USDT, Jan 2025 - Sep 2026: 20 most active participating addresses
q15b_roundtrip_2025_2026_coverage.csv   Share of round-trip gross value with at least one endpoint among the 1/5/10/20 most active addresses, by year (year = 0: whole period)
q16_direct_call_gas.csv                 Transactions calling the token contracts directly: gas-used percentiles and share below 120,000 by token and year
q17_dai_roundtrip_by_address_by_year.csv DAI 2021-2024: the 15 most active participating addresses in flash-loan-like round trips in each year, with their share of the year's round-trip gross value

Note: the entity labels of the four addresses of the 2022 DAI/USDC rebalancing loop (the two Uniswap V3 DAI/USDC pools and the two G-UNI/Arrakis vaults,
GUNIV3DAIUSDC1 and GUNIV3DAIUSDC2) are taken from the MakerDAO collateral documentation cited in the main text [42]; they are not part of the 96-address label table.
